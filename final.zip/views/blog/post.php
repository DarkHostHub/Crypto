
<?php include('views/elements/header.php');?>
<?php
if( is_array($post) ) {
	extract($post);
}?>

<div class="container">
	<div class="page-header"><h1><?php echo $title;?></h1></div>

<?php echo $content;?>
<br>
<sub><?php echo 'Posted on ' . $date . ' by <a href="'.BASE_URL.'members/view/'. $uid.'">'. $first_name . ' ' . $last_name . '</a> in <a href="'.BASE_URL.'category/view/'. $categoryid.'">' . $name .'</a>'; ?>
        </sub>


<div id="cmain"><br><br>


	<div class="well">
<h2>Comments:</h2>
		<?php if(is_array($posts) ) {?>

		<div class="container">
		<div class="page-header">



			<?php foreach($posts as $p){?>
				<hr/>
		    <h3><?php echo $p['first_name']." ".$p['last_name'];?></h3>
			<p><?php echo $p['commentText'];?></p>
			<sub><?php echo $p['date']; ?></sub>
		<br>
		<?php }?>
		</div>

		<?php }?>

</div>


	<form action="http://corsair.cs.iupui.edu:20541/CIT313/SP2017/final/blog/post/<?echo $task; ?>" method="POST">
	    <textarea class="form-control" id="textComment" name="textComment" value="Comments." placeholder="Comments." rows="3" style="width:75%;"></textarea>
	<br>
	    <input type="submit" id="submitComment" class="btn btn-primary" value="Comment">


	    <input type="hidden" name="pid" id="pid" value="110">
	    <input type="hidden" name="uid" id="uid" value="45">

	</form>

</div>


<h4>Login to post comments</h4>
<a href="http://corsair.cs.iupui.edu:20541/CIT313/SP2017/final/login" class="btn btn-primary">Login</a>
<br><br><br><br>
</div>


<?php include('views/elements/footer.php');?>
