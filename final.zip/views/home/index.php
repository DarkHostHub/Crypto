<?php include('views/elements/header.php');?>
<div class="container">
	<div class="page-header">

		<?php echo $_GET['logout_message'];?>


<br><br>
<?php include('views/elements/footer.php');?>
