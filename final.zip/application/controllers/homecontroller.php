<?php

class HomeController extends Controller{


	public function index(){
		$feed = 'http://www.fifa.com/rss/index.xml';
		$rss = new RssDisplay($feed);
		$channel_info = $rss->getChannelInfo();
		//$this->set('rss_title', $channel_info);

		$feed_data = $rss->getFeedItems(10);
		$feed_title = $feed_data->item->title;

		//$this->set('feed_title', $feed_data);
	}


}
