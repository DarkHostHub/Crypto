<?php
class Post extends Model{

	function getPost($pID){

		$sql =
		'SELECT p.pID, p.title, p.content, p.date, p.uID, p.categoryID, c.name, u.first_name, u.last_name
		FROM posts p
		JOIN categories c ON c.categoryID = p.categoryID
		JOIN users u ON p.uID = u.uID WHERE pID = ?';

		// perform query
		$results = $this->db->getrow($sql, array($pID));

		$post = $results;

		return $post;

	}
		// blog/view/1
		// limit is 0 pages
	public function getAllPosts($limit = 0){
		$numposts = '';
		if($limit > 0){

			$numposts = ' LIMIT '.$limit;
		}

		$sql =
		'SELECT p.pID, p.title, p.content, p.date, p.uID, p.categoryID, c.name, u.first_name, u.last_name
		FROM posts p
		JOIN categories c ON c.categoryID = p.categoryID
		JOIN users u ON p.uID = u.uID'.$numposts;

		// perform query
		$results = $this->db->execute($sql);

		while ($row=$results->fetchrow()) {
			$posts[] = $row;
		}

		return $posts;

	}



	// add new post in the DB
	public function addPost($data){

		$sql="INSERT INTO posts (title, date, content, categoryID) VALUES (?, ?, ?, ?)";
		$this->db->execute($sql,$data);
		$message = 'Post added.';
		return $message;

	}

	public function updatePost($data){
		$limit = NULL;
		$numposts = NULL;
		if($limit > 0){
      $numposts = ' LIMIT '.$limit;}

		$date = date("Y/m/d");

		$sql = "UPDATE posts SET title = ?, date = ?, content = ?, categoryID = ? WHERE pID = ?".$numposts;
    $this->db->execute($sql,$data);
		$message = 'Post updated.';
		return $message;

	}

}
