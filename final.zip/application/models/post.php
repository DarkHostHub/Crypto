<?php
class Post extends Model{

	function getPost($pID){

		$sql =
		'SELECT p.pID, p.title, p.content, p.date, p.uID, p.categoryID, c.name, u.first_name, u.last_name
		FROM posts p
		JOIN categories c ON c.categoryID = p.categoryID
		JOIN users u ON p.uID = u.uID WHERE pID = ?';

		// perform query
		$results = $this->db->getrow($sql, array($pID));

		$post = $results;

		return $post;

	}
		// blog/view/1
		// limit is 0 pages
	public function getAllPosts($limit = 0){
		$numposts = '';
		if($limit > 0){

			$numposts = ' LIMIT '.$limit;
		}

		$sql =
		"SELECT p.pID, p.title, p.content, DATE_FORMAT(p.date, '%b %d %Y %I:%i %p') as date, p.uID, p.categoryID, c.name, u.first_name, u.last_name
		FROM posts p
		JOIN categories c ON c.categoryID = p.categoryID
		JOIN users u ON p.uID = u.uID ORDER BY p.date DESC".$numposts;


		// perform query
		$results = $this->db->execute($sql);

		while ($row=$results->fetchrow()) {
			$posts[] = $row;
		}

		return $posts;

	}

// add comment to blog post
public function addComment($data){
	$sql="INSERT INTO comments (date, commentText, uID, postID) VALUES (?, ?, ?, ?)";
	$this->db->execute($sql,$data);
	$message = 'comment added.';
	return $message;

}

public function deletePost($pID){

	$sql="DELETE FROM posts WHERE pID = '".$pID."'";
	$this->db->execute($sql,$pID);
	$message = 'Post deleted.';
	return $message;

}

	// add new post in the DB
	public function addPost($data){

		$sql="INSERT INTO posts (title, date, content, categoryID, uID) VALUES (?, ?, ?, ?, 1)";
		$this->db->execute($sql,$data);
		$message = 'Post added.';
		return $message;

	}

	public function updatePost($data){
		$sql = 'UPDATE posts SET title = ?, content = ?, categoryID = ?, date = ? where pID = ?';
		$this->db->execute($sql, $data);
		$message = "Post updated.";
		return $message;

	}

}
