<?php
class RssDisplay extends Model{

  protected $feed_url, $num_feed_items;

  public function __construct($url){
    parent::__construct();
    $this->feed_url = $url;
  } // end of construct function

  public function getChannelInfo(){
    $item = simplexml_load_file($this->feed_url);
    echo '<div class="container">




    <div class="page-header">

    <h1>UEFA Futbol Blog</h1><hr/>

    <div class="jumbotron">
    <img src="http://orig14.deviantart.net/f0cd/f/2013/105/b/3/borussia_dortmund_by_eqium-d61uk96.jpg" width="100%" class="img  no-repeat center center fixed center top">

                  </div>

    <div class="bs-component">
                  <div class="well">
                    <h2>Latest News from '.$item->channel->title.'</h2>
                  </div>
                </div>


    ';

  }


  public function getFeedItems($num_feed_items){
    $item = simplexml_load_file($this->feed_url);
    $counter = 0;
    foreach($item->channel->item as $item){
      $counter = $counter + 1;

      if ($counter <= $num_feed_items){
        echo'<div><div>';
        echo '<h4><a href="'.$item->link.'">'.$item->title.'</a> ('.date('F d, Y @ g:i a', strtotime($item->pubDate)).')</h4>';
        echo '<p>'.$item->description."</p>";
        echo'</div><hr/></div>';

      }else{
        break;
      }
  }


}




}
?>
