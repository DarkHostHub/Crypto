<?php

class ManagePostsController extends Controller{

	public $postObject;
	protected $access = 1;

	public function index(){

	}

	public function add(){

		$this->set('message', '');
    $this->set('pID', '4');
    $this->set('title','');
    $this->set('PostTitle','Add Post');
    $this->set('date','');
    $this->set('content', '');
    $this->set('categoryID', '');
		#--------------------------------

		$this->postObject = new Post();
		#$this->getCategories();

		$this->set('task', 'save');

	}

	public function save(){
    $this->set('title','');
    $this->set('PostTitle','Add Post');
    $this->set('date',$_POST['post_date']);
    $this->set('categoryID', $_POST['post_categoryID']);

			$this->postObject = new Post();

		$data = array(
      'title'=>$_POST['post_title'],
      'date'=>$_POST['post_date'],
      'content'=>$_POST['post_content'],
      'categoryID'=>$_POST['post_categoryID']
      );
			$result = $this->postObject->addPost($data);
			$this->set('message', $result);

	}


  public function edit($pID){
		$this->postObject = new Post();
		$post = $this->postObject->getPost($pID);
		$this->getCategories();

    $this->set('pID', $pID);
    $this->set('title','');
    $this->set('PostTitle','Add Post');
    $this->set('date','');
    $this->set('content', '');
    $this->set('categoryID', '');

		$this->set('task', 'update');

	}


	public function getCategories(){
		$this->postObject = new Categories();
		$categories = $this->postObject->getCategories();
		$this->set('categories',$categories);
	}

	public function update(){

		$this->set('title',$_POST['post_title']);
    $this->set('PostTitle','Updated Post');
		$this->set('content',$_POST['post_content']);
    $this->set('date',$_POST['post_date']);
    $this->set('categoryID', $_POST['post_categoryID']);

			$this->postObject = new Post();

		$data = array(
      'title'=>$_POST['post_title'],
      'date'=>$_POST['post_date'],
      'content'=>$_POST['post_content'],
      'categoryID'=>$_POST['post_categoryID'],
			'pID'=>$_POST['pID']

      );
			$result = $this->postObject->updatePost($data);
			$this->set('message', $result);
	}

}
?>
