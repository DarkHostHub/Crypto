<?php


class Comments extends Model{

// update  =  save
public function update(){

}



public function delete(){

}


}
 ?>
