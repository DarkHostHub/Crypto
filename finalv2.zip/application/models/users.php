<?php
class Users extends Model{
	public $uID;
	public $first_name;
	public $last_name;
	public $email;
	protected $user_type;

	// contruct
	public function __construct(){
		parent::__construct();
		if(isset($_SESSION['uID'])){
			$userInfo = $this->getUserFromID($_SESSION['uID']);

			$this->uID = $userInfo['uID'];
			$this->first_name = $userInfo['first_name'];
			$this->last_name = $userInfo['last_name'];
			$this->email = $userInfo['email'];
			$this->user_type = $userInfo['user_type'];
		}
	}

	// shows in the home page for the user that is logged in.
	public function getUserName(){
		return $this->first_name.' '.$this->last_name;
	}
	// shows in the home page for the user that is logged in.
	public function getUserEmail(){
		return $this->email;
	}
	// checks if user is regisitered
	public function isRegistered(){
		if(isset($this->user_type)){
			return true;
		}else{
			return false;
		}
	}
// checks if user is an admin
public function isAdmin(){
	if($this->user_type == '1'){
		return true;
	}else{
		return false;
	}

}

	function getUsers($uID){

		$sql = 'SELECT uID, email, first_name, last_name FROM users WHERE uID = ?';

		// perform query
		$results = $this->db->getrow($sql, array($uID));

		$post = $results;

		return $post;

	}
		// blog/view/1
		// limit is 0 pages
	public function getAllUsers($limit = 0){
		$numposts = '';
		if($limit > 0){

			$numposts = ' LIMIT '.$limit;
		}

		$sql = 'SELECT * FROM users'.$numposts;

		// perform query
		$results = $this->db->execute($sql);

		while ($row=$results->fetchrow()) {
			$posts[] = $row;
		}

		return $posts;

	}

	public function getAllUserComments($limit = 0){
		$numposts = '';

		$pID_url = $_SERVER['REQUEST_URI'];
		$res_pid = str_replace("/CIT313/SP2017/final/blog/post/","",$pID_url);



		if($limit > 0){

			$numposts = ' LIMIT '.$limit;
		}

		$sql = "SELECT u.uID, u.first_name, u.last_name, c.commentText, DATE_FORMAT(c.date, '%b %d %Y %I:%i %p') as date FROM users u
						INNER JOIN comments c ON c.uID = u.uID
						INNER JOIN posts p ON p.pID = c.postID
						WHERE $res_pid = p.pID
						ORDER BY  c.date DESC".$numposts;

		// perform query
		$results = $this->db->execute($sql);

		while ($row=$results->fetchrow()) {
			$posts[] = $row;
		}

		return $posts;

	}


	// add new post in the DB
	public function addUser($data = ''){
		$sql="INSERT INTO users (first_name, last_name, email, password) VALUES (?, ?, ?, ?)";
		$this->db->execute($sql,$data);
		$message = 'User added.';
		return $message;

	}

	public function updatePost($data){
		if($limit > 0){

			$numposts = ' LIMIT '.$limit;
		}
		$date = date("Y/m/d");
		$sql="UPDATE posts SET(pID = ?,title = title,content = content, date = date, categoryID = categoryid) WHERE uID = uid".$numposts;
		$this->db->execute($sql,$data);
		$message = 'Post updated.';
		return $message;
	}

		public function CheckUser($email, $password){
			$sql = 'SELECT email, password FROM users WHERE email = ?';
			$results = $this->db->getrow($sql, array($email));

			$user = $results;
			$password_db = $user[1];

			if(password_verify($password, $password_db)){
					return true;
			}else{
					return false;}
		}

		public function getUserFromEmail($email){
			$sql = 'SELECT * FROM users WHERE email = ?';
			$results = $this->db->getrow($sql, array($email));
			$user = $results;
			return $user;
		}

		public function getUserFromID($uID){
			$sql = 'SELECT * FROM users WHERE uID = ?';
			$results = $this->db->getrow($sql, array($uID));
			$user = $results;
			return $user;
		}

}
