
<?php include('views/elements/header.php');?>

<?php if(is_array($posts) ) {?>

<div class="container">
<div class="page-header">

<h1><?php echo $title;?></h1>
  </div>

	<?php foreach($posts as $p){?>
    <h3><a href="<?php echo BASE_URL?>members/users/<?php echo $p['uID'];?>" title="<?php echo $p['email'];?>"><?php echo $p['email'];?></a></h3>
	<p><?php echo $p['first_name']." ".$p['last_name'];?></p>
	<sub><p><?php echo $p['email'];?></p></sub>
<br>
<?php }?>
</div>

<?php }?>


<?php include('views/elements/footer.php');?>
