
<?php include('views/elements/header.php');?>
<?php
if( is_array($post) ) {
	extract($post);

}?>

<div class="container">
	<div class="page-header">

<h1><?php echo "Member ".$uID;?></h1>
<p><?php echo $email; ?></p>
  </div>

<p><?php echo $first_name." ".$last_name;?></p>

<a href="mailto:<?php echo $email;?>"><?php echo $email;?></a>
</div>



<?php include('views/elements/footer.php');?>
