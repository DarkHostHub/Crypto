<?php
include('views/elements/header.php');?>
<div class="container">
	<div class="page-header">

		<h1>UEFA Futbol Blog</h1><hr/>
		<div class="bs-component">
									<div class="well">
										<h1>Latest News from <?php echo $title;?></h1>
									</div>
								</div>

	<div class="jumbotron">
	<img src="http://orig14.deviantart.net/f0cd/f/2013/105/b/3/borussia_dortmund_by_eqium-d61uk96.jpg" width="100%" class="img  no-repeat center center fixed center top">
	</div>
  </div>
    <?php
    echo $data;
    ?>
</div>

<?php include('views/elements/footer.php');?>
